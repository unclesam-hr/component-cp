const mypw = 'hrla30-cp';
const host = 'admin.cmd4su8z0tlg.us-west-1.rds.amazonaws.com'
// mysql -h admin.cmd4su8z0tlg.us-west-1.rds.amazonaws.com -P 3306 -u admin -p

module.exports = {
    mypw,
    host
}