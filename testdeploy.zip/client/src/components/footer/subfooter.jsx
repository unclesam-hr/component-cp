import React from 'react';
import FooterLinkList from './footerlinklist.jsx';

const Subfooter = (props) => {
  return (
    <div className="subfooter" id="subfooter">
        <FooterLinkList />
    </div>
  )
}

export default Subfooter;